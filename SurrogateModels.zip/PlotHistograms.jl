import Plots, Distributions
import KernelDensity
import KernelDensity: kernel_dist
using Measures, DataInterpolations
using LaTeXStrings

kernel_dist(::Type{Distributions.Poisson}, λ::Real) = Distributions.Poisson(λ)

function plot_data_1d(obs1_vecs::Dict{Int, Any}, 
    obs2_vecs::Dict{Int, Any}, t_vecs::Dict{Int, Any})

    obs1_vec = zeros(Float64,0)
    obs2_vec = zeros(Float64,0)
    t_diff_vec = zeros(Float64,0)
    for thread_id in keys(obs1_vecs)
        obs1_vec = vcat(obs1_vec, obs1_vecs[thread_id][1:(end-1)])
        obs2_vec = vcat(obs2_vec, obs2_vecs[thread_id][1:(end-1)])
        t_diff_vec = vcat(t_diff_vec, diff(t_vecs[thread_id]))
    end

    p1 = Plots.histogram(obs2_vec, normalize=:pdf, bins=100, 
        label="QuantumSavory")

    bins_x = p1[1][1][:x]
    bins_y = p1[1][1][:y]
    bins_x = (bins_x[1:2:end] + bins_x[2:2:end]) ./ 2.0
    bins_y = (bins_y[1:2:end] + bins_y[2:2:end]) ./ 2.0

    bins_x = vcat(bins_x, 2*bins_x[end] - bins_x[end-1])
    bins_y = vcat(bins_y, 0.0)

    itp_bins = CubicSpline(sqrt.(bins_y), bins_x,
        extrapolation = ExtrapolationType.Constant)

    dx = (maximum(bins_x) - minimum(bins_x)) / 600.0
    itp_bins_x = minimum(bins_x):dx:maximum(bins_x)
    itp_bins_y = (itp_bins.(itp_bins_x)) .^ 2.0
    Plots.plot!(itp_bins_x, itp_bins_y, lw = 2, label="Cubic Spline")
    
    Plots.plot!(xlabel = "(O₁) Fidelity of consumed pairs", 
        ylabel = "p₁(O₁)")
    Plots.plot!(frame = :box)

    p2 = Plots.histogram(t_diff_vec, normalize=:pdf, bins=200, 
        label="QuantumSavory")
    
    bins_x = p2[1][1][:x]
    bins_y = p2[1][1][:y]
    bins_x = (bins_x[1:2:end] + bins_x[2:2:end]) ./ 2.0
    bins_y = (bins_y[1:2:end] + bins_y[2:2:end]) ./ 2.0

    while bins_x[1] <= 0.0
        bins_x = bins_x[2:end]
        bins_y = bins_y[2:end]
    end

    bins_x = vcat([0], bins_x)
    bins_y = vcat([0], bins_y)
    bins_x = vcat(bins_x, 2*bins_x[end] - bins_x[end-1])
    bins_y = vcat(bins_y, 0.0)

    itp_bins = CubicSpline(sqrt.(bins_y), bins_x, 
        extrapolation = ExtrapolationType.Constant)

    dx = (maximum(bins_x) - minimum(bins_x)) / 600.0
    itp_bins_x = minimum(bins_x):dx:maximum(bins_x)
    itp_bins_y = (itp_bins.(itp_bins_x)) .^ 2.0
    Plots.plot!(itp_bins_x, itp_bins_y, lw = 2, label="Cubic Spline")

    Plots.plot!(xlabel = "(Δt) Time between consumptions [s]", 
        ylabel = "pₜ(Δt)")
    Plots.plot!(frame = :box)

    return Plots.plot(p1, p2, layout = (2,1), 
        size=(800,400), left_margin = 3mm, bottom_margin = 4mm)
end

function plot_data_2d(obs1_vecs::Dict{Int, Any}, 
    obs2_vecs::Dict{Int, Any}, t_vecs::Dict{Int, Any})

    obs1_vec = zeros(Float64,0)
    obs2_vec = zeros(Float64,0)
    t_diff_vec = zeros(Float64,0)
    for thread_id in keys(obs1_vecs)
        obs1_vec = vcat(obs1_vec, obs1_vecs[thread_id][1:(end-1)])
        obs2_vec = vcat(obs2_vec, obs2_vecs[thread_id][1:(end-1)])
        t_diff_vec = vcat(t_diff_vec, diff(t_vecs[thread_id]))
    end

    hist = Plots.histogram2d(obs2_vec, t_diff_vec, bins=(250,250), 
        normalize=:pdf, show_empty_bins=false, color=:jet)
    Plots.plot!(frame=:box)
    Plots.plot!(xlabel="O₁")
    Plots.plot!(ylabel="Δt")
    Plots.plot!(colorbar_title="pₜ₁(Δt,O₁)")
    Plots.plot!(title="Simulated data in QSavory\n(Binned 2D Histogram)")
    return hist
end

function plot_corr_2d(obs1_vecs::Dict{Int, Any}, 
    obs2_vecs::Dict{Int, Any}, t_vecs::Dict{Int, Any})
    obs1_vec = zeros(Float64,0)
    obs2_vec = zeros(Float64,0)
    t_diff_vec = zeros(Float64,0)
    for thread_id in keys(obs1_vecs)
        obs1_vec = vcat(obs1_vec, obs1_vecs[thread_id][1:(end-1)])
        obs2_vec = vcat(obs2_vec, obs2_vecs[thread_id][1:(end-1)])
        t_diff_vec = vcat(t_diff_vec, diff(t_vecs[thread_id]))
    end

    function pdf_cubic_interpolant(data::Vector{Float64}, bins::Int)
        hist = Plots.histogram(data, normalize=:pdf, bins=bins)
        
        bins_x = hist[1][1][:x]
        bins_y = hist[1][1][:y]
        bins_x = (bins_x[1:2:end] + bins_x[2:2:end]) ./ 2.0
        bins_y = (bins_y[1:2:end] + bins_y[2:2:end]) ./ 2.0

        while bins_x[1] <= 0.0
            bins_x = bins_x[2:end]
            bins_y = bins_y[2:end]
        end

        bins_x = vcat([0], bins_x)
        bins_y = vcat([0], bins_y)
        bins_x = vcat(bins_x, 2*bins_x[end] - bins_x[end-1])
        bins_y = vcat(bins_y, 0.0)

        return CubicSpline(sqrt.(bins_y), bins_x,
            extrapolation = ExtrapolationType.Constant)
    end

    itp1 = pdf_cubic_interpolant(obs2_vec, 100)
    itp2 = pdf_cubic_interpolant(t_diff_vec, 200)
    hist2d = Plots.histogram2d(obs2_vec, t_diff_vec, bins=(250,250),
        normalize=:pdf)

    x_bins = hist2d[1][1][:x]
    y_bins = hist2d[1][1][:y]
    z_bins = hist2d[1][1][:z].surf

    x_vec = Float64[]
    y_vec = Float64[]
    counts_vec = Float64[]

    for i in eachindex(x_bins), j in eachindex(y_bins)
        val = z_bins[j, i]
        if val > 0 
            push!(x_vec, x_bins[i])
            push!(y_vec, y_bins[j])
            push!(counts_vec, val)
        end
    end

    corr_data = counts_vec[:]
    uncorr_data = (itp1.(x_vec[:]) .* itp2.(y_vec[:])) .^ 2.0

    dx = (maximum(uncorr_data) - minimum(uncorr_data)) / 10.0
    model_x = collect(minimum(uncorr_data):dx:maximum(uncorr_data))
    model_y = model_x

    plt = Plots.scatter(uncorr_data, corr_data, label="Simulated data")
    Plots.plot!(model_x, model_y, label="f(x) = x", lw = 4)
    Plots.plot!(xlabel="pₜ(Δt) p₁(O₁)")
    Plots.plot!(ylabel="pₜ₁(Δt,O₁)")
    Plots.plot!(frame=:box)
    return plt
end

function plot_data_model_2d(obs1_vecs::Dict{Int, Any}, 
    obs2_vecs::Dict{Int, Any}, t_vecs::Dict{Int, Any})

    obs1_vec = zeros(Float64,0)
    obs2_vec = zeros(Float64,0)
    t_diff_vec = zeros(Float64,0)
    for thread_id in keys(obs1_vecs)
        obs1_vec = vcat(obs1_vec, obs1_vecs[thread_id][1:(end-1)])
        obs2_vec = vcat(obs2_vec, obs2_vecs[thread_id][1:(end-1)])
        t_diff_vec = vcat(t_diff_vec, diff(t_vecs[thread_id]))
    end

    function pdf_cubic_interpolant(data::Vector{Float64}, bins::Int)
        hist = Plots.histogram(data, normalize=:pdf, bins=bins)
        
        bins_x = hist[1][1][:x]
        bins_y = hist[1][1][:y]
        bins_x = (bins_x[1:2:end] + bins_x[2:2:end]) ./ 2.0
        bins_y = (bins_y[1:2:end] + bins_y[2:2:end]) ./ 2.0

        while bins_x[1] <= 0.0
            bins_x = bins_x[2:end]
            bins_y = bins_y[2:end]
        end

        bins_x = vcat([0], bins_x)
        bins_y = vcat([0], bins_y)
        bins_x = vcat(bins_x, 2*bins_x[end] - bins_x[end-1])
        bins_y = vcat(bins_y, 0.0)

        return CubicSpline(sqrt.(bins_y), bins_x, 
            extrapolation = ExtrapolationType.Constant)
    end

    itp1 = pdf_cubic_interpolant(obs2_vec, 100)
    itp2 = pdf_cubic_interpolant(t_diff_vec, 200)

    dx = (maximum(obs2_vec) - minimum(obs2_vec)) / 400.0
    x_pts = minimum(obs2_vec):dx:maximum(obs2_vec)

    dy = (maximum(t_diff_vec) - minimum(t_diff_vec)) / 400.0
    y_pts = minimum(t_diff_vec):dy:maximum(t_diff_vec)

    p_model(O₁,Δt) =  (itp2(Δt) * itp1(O₁)) ^ 2.0
    plt = Plots.heatmap(x_pts, y_pts, p_model, color=:jet)

    Plots.plot!(frame=:box)
    Plots.plot!(xlabel="O₁")
    Plots.plot!(ylabel="Δt")
    Plots.plot!(colorbar_title="pₜ(Δt) p₁(O₁)")
    Plots.plot!(title="Treating O₁ and Δt as\nindependent random variables")
    return plt
end

function load_data(save_dir::String)
    obs1_vecs = Dict{Int, Any}()
    obs2_vecs = Dict{Int, Any}()
    t_vecs = Dict{Int, Any}()

    function load_config(file_name::String)
        config = Dict{String, Any}()
        open(file_name, "r") do io
            for line in eachline(io)
                split_line = split(line, " = ")
                config[split_line[1]] = eval(Meta.parse(split_line[2]))
            end
        end
        return config
    end

    config = load_config(save_dir * "config.txt")
    n_samples = config["n_sample_files"]

    function load_observations(file_name::String)
        obs1_vec = Float64[]
        obs2_vec = Float64[]
        t_vec = Float64[]
        open(file_name, "r") do io
            for line in eachline(io)
                split_line = split(line)
                push!(obs1_vec, parse(Float64, split_line[1]))
                push!(obs2_vec, parse(Float64, split_line[2]))
                push!(t_vec, parse(Float64, split_line[3]))
            end
        end
        return obs1_vec, obs2_vec, t_vec
    end

    for sample_id in 1:n_samples
        obs1_vecs[sample_id], obs2_vecs[sample_id], t_vecs[sample_id] = 
            load_observations(save_dir * "observations_sample_$(sample_id).txt")
    end

    return obs1_vecs, obs2_vecs, t_vecs
end

function plot_data(save_dir::String)
    obs1_vecs, obs2_vecs, t_vecs = load_data(save_dir)
    plot = plot_data_1d(obs1_vecs, obs2_vecs, t_vecs)
    Plots.savefig(plot, save_dir * "histograms_univariate.pdf")

    plot1 = plot_data_2d(obs1_vecs, obs2_vecs, t_vecs)
    plot2 = plot_data_model_2d(obs1_vecs, obs2_vecs, t_vecs)
    plot = Plots.plot(plot1,plot2,layout=(1,2),size=(900,300),
        left_margin = 4mm, bottom_margin = 4mm, top_margin=8mm)
    Plots.savefig(plot, save_dir * "histograms_bivariate.pdf")

    plot = plot_corr_2d(obs1_vecs, obs2_vecs, t_vecs)
    Plots.savefig(plot, save_dir * "model_corr_plot.pdf")

    return plot
end


plot_data("saved_data/F_0.5/")
plot_data("saved_data/F_0.55/")
plot_data("saved_data/F_0.6/")
plot_data("saved_data/F_0.65/")
plot_data("saved_data/F_0.7/")
plot_data("saved_data/F_0.75/")
plot_data("saved_data/F_0.8/")
plot_data("saved_data/F_0.85/")
plot_data("saved_data/F_0.9/")
plot_data("saved_data/F_0.95/")

